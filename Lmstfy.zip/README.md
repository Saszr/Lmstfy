### 简介

项目整合

### 来源项目

[🔍 让我帮你百度一下？Let Me Baidu That For You](https://github.com/mengkunsoft/lmbtfy)
[🔍 让我帮你Google一下？Let Me Google That For You](https://github.com/yuxizhe/google)
[🔍 有求必应？Ask and it is given](https://github.com/MisterBoole/lmbtfy)
